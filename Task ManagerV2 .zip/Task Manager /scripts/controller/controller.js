import { taskOperations } from "../services/services.js";

window.addEventListener("load", initEvents);

function initEvents() {
  const addTaskButton = document.getElementById("add-task");
  addTaskButton.addEventListener("click", addTask);
  const editTaskButton = document.getElementById("edit-task");
  editTaskButton.disabled = true;
  editTaskButton.addEventListener("click", editTask);
}

function addTask() {
  const ids = ["id", "name", "description", "date", "priority", "color"];
  const taskObject = {};
  for (let id of ids) {
    taskObject[id] = document.getElementById(id).value;
  }
  taskOperations.addTask(taskObject);
  for (let id of ids) {
    document.getElementById(id).value = "";
  }
  printTasks();
}

function fillDetails(id) {
  const ids = ["id", "name", "description", "date", "priority", "color"];
  const task = taskOperations.getTask(id);
  console.log("Task is", task);
  for (let id of ids) {
    document.getElementById(id).value = task[id];
  }
  document.getElementById("edit-task").disabled = false;
}

function editTask() {
  const ids = ["id", "name", "description", "date", "priority", "color"];
  const taskObject = {};
  for (let id of ids) {
    taskObject[id] = document.getElementById(id).value;
  }
  taskOperations.updateTask(taskObject);
  for (let id of ids) {
    document.getElementById(id).value = "";
  }
  printTasks();
}
function deleteTask(id) {
  taskOperations.deleteTask(id);
  printTasks();
}
function printTasks() {
  const tasksDiv = document.getElementById("tasks");
  tasksDiv.innerHTML = "";
  taskOperations.tasks.map((task) => printSingleTask(task, tasksDiv));
}

function printSingleTask(task, tasksDiv) {
  const div = document.createElement("div");
  div.style.height = "max-content";
  div.style.width = "200px";
  const id = document.createElement("h5");
  id.innerText = task.id;
  const name = document.createElement("h5");
  name.innerText = task.name;
  const desc = document.createElement("p");
  desc.innerText = task.description;
  const date = document.createElement("h6");
  date.innerText = task.date;
  const priority = document.createElement("h4");
  priority.innerText = task.priority;
  const color = document.createElement("div");
  color.style.backgroundColor = task.color;
  color.style.height = "50px";
  color.style.width = "100px";
  color.style.marginBottom = "4px";
  div.style.border = "0.5px solid grey";
  div.style.display = "flex";
  div.style.justifyContent = "center";
  div.style.alignItems = "center";
  div.style.flexDirection = "column";
  div.style.borderRadius = "4px";
  const editButton = document.createElement("button");
  const editIcon = document.createElement("i");
  editIcon.classList = "fa fa-pen";
  editButton.append(editIcon);
  editButton.classList = "btn btn-primary";
  const deleteButton = document.createElement("button");
  const deleteIcon = document.createElement("i");
  deleteIcon.classList = "fa fa-trash";
  deleteButton.append(deleteIcon);
  deleteButton.classList = "btn btn-danger";
  editButton.addEventListener("click", () => fillDetails(task.id));

  deleteButton.addEventListener("click", () => deleteTask(task.id));
  div.append(id, name, desc, date, priority, color, editButton, deleteButton);
  tasksDiv.style.gap = "20px";

  tasksDiv.append(div);
}
