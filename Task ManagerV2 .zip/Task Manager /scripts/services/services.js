import { TaskModel } from "../models/models.js";

export const taskOperations = {
  tasks: [],
  addTask(taskObject) {
    console.log("Is=d is ", taskObject);
    let isFound = this.tasks.find((task) => task.id === taskObject.id);
    console.log("is Found", isFound);
    if (!isFound && taskObject.id != "") {
      console.log("Enter");
      const task = new TaskModel(taskObject);
      this.tasks.push(task);
    }
  },
  deleteTask(id) {
    let deleteIndex = this.tasks.findIndex((task) => task.id === id);
    if (deleteIndex != -1) {
      this.tasks.splice(deleteIndex, 1);
    }
  },
  updateTask(taskObject) {
    let updateIndex = this.tasks.findIndex((task) => task.id === taskObject.id);
    if (updateIndex != -1) {
      this.tasks.splice(updateIndex, 1, taskObject);
    }
  },
  getTask(id) {
    let task = this.tasks.find((task) => task.id === id);
    return task;
  },
};
