import { TaskModel } from "../models/models.js";

export const taskOperations = {
  tasks: [],
  addTask(taskObject) {
    let isFound = this.tasks.find((task) => task.id === taskObject.id);
    console.log("is Found", isFound);
    if (!isFound) {
      console.log("Enter");
      const task = new TaskModel(taskObject);
      this.tasks.push(task);
    }
  },
  deleteTask() {},
  updateTask() {},
  getTask() {},
};
