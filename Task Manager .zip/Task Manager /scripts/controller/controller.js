import { taskOperations } from "../services/services.js";

window.addEventListener("load", initEvents);

function initEvents() {
  const addTaskButton = document.getElementById("add-task");
  addTaskButton.addEventListener("click", addTask);
}

function addTask() {
  const ids = ["id", "name", "description", "date", "priority", "color"];
  const taskObject = {};
  for (let id of ids) {
    taskObject[id] = document.getElementById(id).value;
  }
  taskOperations.addTask(taskObject);
  printTasks();
}

function printTasks() {
  const tasksDiv = document.getElementById("tasks");
  tasksDiv.innerHTML = "";
  taskOperations.tasks.map((task) => printSingleTask(task, tasksDiv));
}

function printSingleTask(task, tasksDiv) {
  const div = document.createElement("div");
  div.style.height = "500px";
  div.style.width = "300px";
  const id = document.createElement("h5");
  id.innerText = task.id;
  const name = document.createElement("h5");
  name.innerText = task.name;
  const desc = document.createElement("p");
  desc.innerText = task.description;
  const date = document.createElement("h6");
  date.innerText = task.date;
  const priority = document.createElement("h4");
  priority.innerText = task.priority;
  const color = document.createElement("div");
  color.style.backgroundColor = task.color;
  color.style.height = "50px";
  color.style.width = "100px";
  div.append(id, name, desc, date, priority, color);
  tasksDiv.append(div);
}
